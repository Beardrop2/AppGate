fn main() {
    println!("tcp module stub");
}