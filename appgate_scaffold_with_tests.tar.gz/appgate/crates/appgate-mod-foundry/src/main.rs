fn main() {
    println!("foundry module stub");
}