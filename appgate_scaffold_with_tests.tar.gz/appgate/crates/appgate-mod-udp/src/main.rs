fn main() {
    println!("udp module stub");
}